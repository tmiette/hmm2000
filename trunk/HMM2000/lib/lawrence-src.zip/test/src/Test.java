import java.util.Collections;
import java.util.List;
import java.util.Random;

import fr.umlv.lawrence.Application;
import fr.umlv.lawrence.CursorListener;
import fr.umlv.lawrence.DefaultGridModel;
import fr.umlv.lawrence.GridPane;
import fr.umlv.lawrence.svg.SVGImageProvider;

public class Test {
  public static enum Element {
    a,b,c,d;
    static Element[] VALUES=values();
  }
  
  public static void main(String[] args) {
    /*BitmapImageProvider<Element> provider = new BitmapImageProvider<Element>();
    for(Element v:Element.VALUES) {
      provider.registerImage(v, Test.class.getResource(v.name()+".png"));
    }*/
    SVGImageProvider<Element> resizer = new SVGImageProvider<Element>();
    for(Element v:Element.VALUES) {
      resizer.registerImage(v, Test.class.getResource(v.name()+".svg"));
    }
    @SuppressWarnings("unchecked") List<Element>[][] init = (List<Element>[][]) new List<?>[4][4];
    Random rnd = new Random();
    for(int x=0;x<4;x++)
      for(int y=0;y<4;y++)
        init[x][y]=Collections.singletonList(Element.VALUES[rnd.nextInt(Element.VALUES.length)]);
    final DefaultGridModel<Element> model = new DefaultGridModel<Element>(init);
    final GridPane<Element> pane = new GridPane<Element>(model,resizer,40,40);
    
    pane.addCursorListener(new CursorListener() {
      public void mouseExited(int x, int y) {
        model.setHighligthElement(x,y,null);
      }
      public void mouseEntered(int x, int y) {
        model.setHighligthElement(x, y, Element.a);
      }
    });
    
    Application.display(pane, "Test", true, true);
  }
}

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Random;

import fr.umlv.lawrence.Application;
import fr.umlv.lawrence.CursorListener;
import fr.umlv.lawrence.DefaultGridModel;
import fr.umlv.lawrence.GridPane;
import fr.umlv.lawrence.svg.SVGImageProvider;

public class PerfTest {
  public static enum Element {
    a,b,c,d;
    static Element[] VALUES=values();
  }

  static final Random random = new Random();

  public static void main(String[] args) {
    /*BitmapImageProvider<Element> provider = new BitmapImageProvider<Element>();
    for(Element v:Element.VALUES) {
      provider.registerImage(v, PerfTest.class.getResource(v.name()+".png"));
    }*/
    
    int numberOfSprites=20;
    
    int length=Element.VALUES.length;
    SVGImageProvider<Integer> provider = new SVGImageProvider<Integer>();
    for(int i=0;i<numberOfSprites;i++) {
      Element element=Element.VALUES[i%length];
      provider.registerImage(i, PerfTest.class.getResource(element.name()+".svg"));
    }

    int size=100;

    final DefaultGridModel<Integer> model =
      new DefaultGridModel<Integer>(size,size,Collections.<Integer>emptyList());
    final GridPane<Integer> pane = new GridPane<Integer>(model,provider,40,40);
    pane.addCursorListener(new CursorListener() {
      public void mouseExited(int x, int y) {
        model.setHighligthElement(x,y,null);
      }
      public void mouseEntered(int x, int y) {
        model.setHighligthElement(x, y, 0);
      }
    });
    
    Application.display(pane, "PerfTest", true, true);
    
    List<Integer> cont = Arrays.asList(0);
    for(int loop=0;;loop++) {
      int x=random.nextInt(size);
      int y=random.nextInt(size);
      cont.set(0,random.nextInt(length));

      model.setDeffered(x,y,cont);

      if (loop==size*100) {
        model.swap();
        //System.out.println("loop swap "+System.nanoTime());
        loop=0;
      }

      //Thread.sleep(1);
    }

  }
}

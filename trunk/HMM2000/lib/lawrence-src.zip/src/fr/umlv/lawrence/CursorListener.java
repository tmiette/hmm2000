/*
 * Created on 22 sept. 2005
 */
package fr.umlv.lawrence;

import java.util.EventListener;

public interface CursorListener extends EventListener {
  /**
   * Indicate that a cell was entered.
   * @param x the x coordinate of the cell
   * @param y the y coordinate of the cell
   */
  public void mouseEntered(int x,int y);
  /**
   * Indicate that a cell was exited.
   * @param x the x coordinate of the cell
   * @param y the y coordinate of the cell
   */
  public void mouseExited(int x,int y);
}

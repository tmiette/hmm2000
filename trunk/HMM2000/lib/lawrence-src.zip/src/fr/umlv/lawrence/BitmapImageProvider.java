/**
 * 
 */
package fr.umlv.lawrence;

import java.awt.Image;
import java.io.IOException;
import java.net.URL;

import javax.swing.ImageIcon;

public class BitmapImageProvider<E> extends AbstractImageProvider<E, Image> {
  @Override
  protected Image parse(URL source) throws IOException {
    if (source==null)
      throw new IllegalArgumentException("null source, resource is probably missing");
    Image img = new ImageIcon(source).getImage();
    //Image img=ImageIO.read(source);
    if (img==null)
      throw new IllegalArgumentException("I/O when reading "+source);
    return img;
  }
  
  @Override
  protected Image render(Image original, int tileWidth, int tileHeight) {
    return original.getScaledInstance(tileWidth, tileHeight, Image.SCALE_FAST);
  }
}
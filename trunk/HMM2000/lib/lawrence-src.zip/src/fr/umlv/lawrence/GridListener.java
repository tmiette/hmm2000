/*
 * Created on 20 sept. 2005
 */
package fr.umlv.lawrence;

import java.util.EventListener;

/**
 * Defines an object which listen for changes in the GridModel
 * @author Julien Cervelle
 */
public interface GridListener extends EventListener {
  /**
   * Notify that the cells within the rectangle whose
   * upper-left corner has coordinate (x,y), width dx
   * and height dy has changed
   * @param x x coordinate of the rectangle whose cells has changed
   * @param y y coordinate of the rectangle whose cells has changed
   * @param dx width of the rectangle whose cells has changed
   * @param dy height of the rectangle whose cells has changed
   */
  void areaChanged(int x,int y,int dx,int dy);
}

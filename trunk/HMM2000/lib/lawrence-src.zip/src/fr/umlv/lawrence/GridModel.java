/*
 * Created on 20 sept. 2005
 */
package fr.umlv.lawrence;

import java.util.Collection;
import java.util.Map;

/**
 * Defines an object that represent a grid whose cells are filled with
 * items of type E.
 * 
 * @param <E> type of the elements.
 * 
 * @author Julien Cervelle
 */
public abstract class GridModel<E> {
  /**
   * @return the height of the grid (number of cells)
   */
  public abstract int getHeight();
  /**
   * @return the width of the grid (number of cells)
   */
  public abstract int getWidth();
  
  /**
   * Indicate what elements are present at cell (x,y).
   * 
   * @param x x coordinate of the cell
   * @param y y coordinate of the cell
   * @return elements presents in cell (x,y), from the lowest to the highest
   */
  abstract Collection<? extends E> getElements(int x,int y);
   
   /** Returns a map that associate a position to an highlighted elements.
    *  An highlighted elements is an element that will be always
    *  in front of all other elements.
    *  This method is useful to implement a selection mechanism.
    * 
    * @return a map of all highlighted elements.
    */
  abstract Map<Location,? extends E> getHighlightedElements();
   
   /**
    * Register a GridListener to be notified of changes in the model
    * @param listener the GridListener to register
    */
   public abstract void addGridListener(GridListener listener);
   /**
    * Remove a GridListener notified of changes in the model
    * @param listener the GridListener to remove
    */
   public abstract void removeGridListener(GridListener listener);
}

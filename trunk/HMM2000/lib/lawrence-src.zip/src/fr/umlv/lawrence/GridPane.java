/*
 * Created on 20 sept. 2005
 */
package fr.umlv.lawrence;

import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.MouseInfo;
import java.awt.Point;
import java.awt.PointerInfo;
import java.awt.Rectangle;
import java.awt.Window;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionAdapter;
import java.awt.event.MouseMotionListener;
import java.lang.reflect.InvocationTargetException;
import java.util.EnumMap;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.LinkedBlockingQueue;

import javax.swing.JComponent;
import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;
import javax.swing.event.AncestorEvent;
import javax.swing.event.AncestorListener;

/**
 * View of a GridModel whose values are represented by images given by
 * an ImageProvider
 * @author Julien Cervelle
 * 
 * @param <E> type of elements.
 */

public class GridPane<E> {
  final GridModel<? extends E> model;
  int tileWidth,tileHeight;
  final CopyOnWriteArrayList<InputListener> inputListeners=
    new CopyOnWriteArrayList<InputListener>();
  final CopyOnWriteArrayList<CursorListener> cursorListeners=
    new CopyOnWriteArrayList<CursorListener>();
  private final MouseListener mouseListener = createMouseListener();
  private final MouseMotionListener mouseMotionListener = createMouseMotionListener();
  private final KeyListener keyListener = createKeyListener();
  final ImageProvider<E> imageProvider;
  
  @SuppressWarnings("serial")
  final JComponent control=new JComponent() {
    @Override
    public Dimension getPreferredSize() {
      return new Dimension(tileWidth*model.getWidth(),
          tileHeight*model.getHeight());
    }
    
    @Override
    public Dimension getMaximumSize() {
      return getPreferredSize();
    }
    
    @Override
    public Dimension getMinimumSize() {
      return getPreferredSize();
    }
    
    @Override
    protected void paintComponent(Graphics g) {
      Rectangle area = g.getClipBounds();
      int minx=area.x/tileWidth;
      int miny=area.y/tileHeight;
      int maxx = Math.min(model.getWidth(),(area.x+area.width+tileWidth-1)/tileWidth);
      int maxy = Math.min(model.getHeight(),(area.y+area.height+tileHeight-1)/tileHeight);
      // display elements
      for (int x=minx; x<maxx;x++) {
        for (int y=miny; y<maxy; y++) {
          for (E value : model.getElements(x, y)) {
            Image img = imageProvider.getImage(value);
            g.drawImage(img, x*tileWidth, y*tileHeight, this);
          }
        }
      }
      
      // display highligths
      Map<Location, ? extends E> highligths = model.getHighlightedElements();
      if (highligths.isEmpty())
        return;
      for(Map.Entry<Location,? extends E> entry:highligths.entrySet()) {
        Location location=entry.getKey();
        int x=location.getX();
        int y=location.getY();
        
        // clipping
        if (x<minx || x>=maxx || y<miny || y>=maxy)
          continue;
        
        Image img = imageProvider.getImage(entry.getValue());
        g.drawImage(img, x*tileWidth, y*tileHeight, this);
      }
    }
  };
  
  /**
   * Construct an object that control the graphical view of a GridModel.
   * 
   * @param model the model to represent
   * @param imageProvider an object that is able to provide an image
   *        for each element of the model.
   * @param tileWidth the width for the tile representing a element
   * @param tileHeight the width for the tile representing a element
   */
  public GridPane(GridModel<? extends E> model, 
      ImageProvider<E> imageProvider, int tileWidth,int tileHeight) {
    this.model = model;
    this.imageProvider = imageProvider;
    imageProvider.seal(tileWidth,tileHeight);
    control.setFocusable(true);
    model.addGridListener(createGridListener());
    control.addAncestorListener(new AncestorListener() {
    
      private void doit() {
        if (control.isVisible())
          control.requestFocusInWindow();
      }
      
      public void ancestorMoved(AncestorEvent event) {
        doit();
      }
    
      public void ancestorRemoved(AncestorEvent event) {
        doit();
      }
    
      public void ancestorAdded(AncestorEvent event) {
        doit();
      }
    
    });
    this.tileWidth = tileWidth;
    this.tileHeight = tileHeight;
  }
  
  /**
   * @return the underlying swing component
   */
  JComponent getControl() {
    return control;
  }
  
  /**
   * @return the height for the tile representing a value in pixels
   */
  int getTileHeight() {
    return tileHeight;
  }

  /**
   * @return the width for the tile representing a value in pixels
   */
  int getTileWidth() {
    return tileWidth;
  }
  
  /**
   * Register a InputListener to be notified of user action
   * @param listener the InputListener to register
   */
  public void addInputListener(InputListener listener) {
    synchronized(inputListeners) {
      if (inputListeners.isEmpty()) {
        control.addMouseListener(mouseListener);
        control.addKeyListener(keyListener);
      }
      inputListeners.add(listener);
    }
  }
  
  /**
   * Remove a InputListener from notification
   * @param listener the InputListener to remove
   */
  public void removeInputListener(InputListener listener) {
    synchronized(inputListeners) {
      inputListeners.remove(listener);
      if (inputListeners.isEmpty()) {
        control.removeMouseListener(mouseListener);
        control.removeKeyListener(keyListener);
      }
    }
  }
  
  /**
   * Returns all registered input listeners.
   * @return all registered input listeners.
   */
  public InputListener[] getInputListeners() {
    synchronized(inputListeners) {
      return inputListeners.toArray(new InputListener[inputListeners.size()]);
    }
  }
  
  /**
   * Register a CursorListener to be notified of user action
   * @param listener the InputListener to register
   */
  public void addCursorListener(CursorListener listener) {
    synchronized(cursorListeners) {
      if (cursorListeners.isEmpty()) {
        control.addMouseMotionListener(mouseMotionListener);
      }
      cursorListeners.add(listener);
    }
  }
  
  /**
   * Remove a InputListener from notification
   * @param listener the InputListener to remove
   */
  public void removeCursorListener(CursorListener listener) {
    synchronized(cursorListeners) {
      cursorListeners.remove(listener);
      if (cursorListeners.isEmpty()) {
        control.removeMouseMotionListener(mouseMotionListener);
      }
    }
  }
  
  /**
   * Returns all registered cursor listeners.
   * @return all registered cursor listeners.
   */
  public CursorListener[] getCursorListeners() {
    synchronized(cursorListeners) {
      return cursorListeners.toArray(new CursorListener[cursorListeners.size()]);
    }
  }
  
  /**
   * Notice registered InputListener of button press
   */
  void fireMouseClicked(final int x,final int y,final int button) {
    Application.postInApplicationThread(new Runnable() {
      public void run() {
        for(InputListener inputListener:inputListeners)
            inputListener.mouseClicked(x, y, button);
      }
    });
  }

  /**
   * Notice registered InputListener of key press
   */
  void fireKeyTyped(final int x,final int y,final Key key) {
    Application.postInApplicationThread(new Runnable() {
      public void run() {
        for(InputListener inputListener:inputListeners) {
          inputListener.keyTyped(x, y, key);
        }
      }
    });
  }

  /**
   * Notice registered CursorListeners of cursor enter
   */
  void fireMouseEntered(final int x,final int y) {
    Application.postInApplicationThread(new Runnable() {
      public void run() {
        for(CursorListener cursorListener: cursorListeners) 
          cursorListener.mouseEntered(x, y);
      }
    });
  }

  /**
   * Notice registered CursorListeners of cursor leave
   */
  void fireMouseExited(final int x,final int y) {
    Application.postInApplicationThread(new Runnable() {
      public void run() {
        for(CursorListener cursorListener: cursorListeners) 
          cursorListener.mouseExited(x, y);
      }
    });
  }
  
  /**
   * Change tile dimension
   * @param tileWidth new tile width in pixels
   * @param tileHeight new tile height in pixels
   */
  void setTileDimension(final int tileWidth,final int tileHeight) {
    if (tileWidth == this.tileWidth &&
        tileHeight == this.tileHeight)
      return;
    
    try {
      rescaleQueue.put(new Runnable() {
        public void run() {
          final Image[] images=imageProvider.processScaleImages(tileWidth,tileHeight);
          
          EventQueue.invokeLater(new Runnable() {
            public void run() {
              imageProvider.applyScaleImages(images);
              GridPane.this.tileWidth = tileWidth;
              GridPane.this.tileHeight = tileHeight;
              control.revalidate();
              SwingUtilities.getRootPane(control).repaint();

              Point locationOnScreen = control.getLocationOnScreen();
              Point cursorPosition = MouseInfo.getPointerInfo().getLocation();
              int dx=cursorPosition.x-locationOnScreen.x;
              int dy=cursorPosition.y-locationOnScreen.y;
              if (dx<0 || dy<0 || dx>=control.getWidth() || dy>=control.getHeight())
                return;
              pointerMoved(dx,dy);
            }
          });
        }
      });
    } catch (InterruptedException e) {
      Thread.currentThread().interrupt();
    }
    /*
    final Image[] images=imageProvider.processScaleImages(tileWidth,tileHeight);
    imageProvider.applyScaleImages(images);

    this.tileWidth = tileWidth;
    this.tileHeight = tileHeight;


    control.revalidate();

    Point locationOnScreen = control.getLocationOnScreen();
    Point cursorPosition = MouseInfo.getPointerInfo().getLocation();
    int dx=cursorPosition.x-locationOnScreen.x;
    int dy=cursorPosition.y-locationOnScreen.y;
    if (dx<0 || dy<0 || dx>=control.getWidth() || dy>=control.getHeight())
      return;
    pointerMoved(dx,dy);
    */
  }
  
  final LinkedBlockingQueue<Runnable> rescaleQueue;
  {
    final LinkedBlockingQueue<Runnable> rescaleQueue=
      new LinkedBlockingQueue<Runnable>();
    this.rescaleQueue=rescaleQueue;
    Thread rescaleThread = new Thread(new Runnable() {
      public void run() {
        for(;;) {
          try {
            int size=rescaleQueue.size();
            if (size>1) {
              // garbage all previous runnables
              for(;--size>0;) {
                rescaleQueue.take();
              }
            }
            
            rescaleQueue.take().run();
          } catch (InterruptedException e) {
            e.printStackTrace();
          }
        }
      }
    },"lawrence-rescale-thread");
    rescaleThread.setDaemon(true);
    rescaleThread.start();
  }
  
  /*
   * Create the listener to be notified of model changes
   */
  private GridListener createGridListener() {
    return new GridListener() {
      public void areaChanged(int x, int y, int dx, int dy) {
        control.paintImmediately(x*tileWidth, y*tileHeight, dx*tileWidth, dy*tileHeight);
      }
    };
  }
  
  public Location pointerPosition() {
    Point locationOnScreen = control.getLocationOnScreen();
    Point cursorPosition = MouseInfo.getPointerInfo().getLocation();
    int dx=cursorPosition.x-locationOnScreen.x;
    int dy=cursorPosition.y-locationOnScreen.y;
    return viewToModel(dx, dy);
  }
  
  /*
   * Create the MouseListener to be notified of user action
   */
  private MouseListener createMouseListener() {
    return new MouseAdapter() {
      private final Location[] cells=
        new Location[MouseInfo.getNumberOfButtons()];
      
      @Override
      public void mouseReleased(MouseEvent e) {
        int btn = e.getButton();
        Location savedPoint = cells[btn-1];
        if(savedPoint == null)
          return;
        if (savedPoint.equals(viewToModel(e.getX(),e.getY())))
          fireMouseClicked(savedPoint.getX(),savedPoint.getY(),btn);
        cells[btn-1]=null;
      }
    
      @Override
      public void mousePressed(MouseEvent e) {
        cells[e.getButton()-1] = viewToModel(e.getX(), e.getY());
      }
    };
  }
  
  /*
   * Create the MouseListener to be notified of user action
   */
  private MouseMotionListener createMouseMotionListener() {
    return new MouseMotionAdapter() {
      @Override
      public void mouseMoved(MouseEvent e) {
        pointerMoved(e.getX(),e.getY());
      }
    };
  }
  
  void pointerMoved(int x,int y) {
    Location point = viewToModel(x,y);
    if (oldPoint!=null) {
      if (oldPoint.equals(point)) // point may be null
        return;
      fireMouseExited(oldPoint.getX(),oldPoint.getY());
    }
    oldPoint=point;
    if (point==null)
      return;
      
    fireMouseEntered(point.getX(),point.getY());
  }
  private Location oldPoint;
  
  /*
   * Create the KeyListener to be notified of user action
   */
  private KeyListener createKeyListener() {
    return new KeyAdapter() {
      private final EnumMap<Key,Location> map = new EnumMap<Key,Location>(Key.class);
      @Override
      public void keyReleased(KeyEvent e) {
        Key key = Key.getKey(e.getKeyCode());
        Location savedPoint = map.remove(key);
        if (savedPoint == null)
          return;
        Location p = getModelPointerCoordinates();
        if (savedPoint.equals(p))
          fireKeyTyped(p.getX(), p.getY(), key);
      }
    
      @Override
      public void keyPressed(KeyEvent e) {
        map.put(Key.getKey(e.getKeyCode()),getModelPointerCoordinates());
      }
      
      /* return cell under the pointer coordinates and null if out of grid */ 
      private Location getModelPointerCoordinates() {
        PointerInfo info = MouseInfo.getPointerInfo();
        if (! info.getDevice().equals(control.getGraphicsConfiguration().getDevice()))
          return null;
        Point p = info.getLocation();
        SwingUtilities.convertPointFromScreen(p, control);
        return viewToModel(p.x, p.y);
      }
    
    };
  }
  
  /**
   * Indicate which tile contains the specified
   * point in pixel coordinates of the view
   * @param x x coordinate in the view
   * @param y y coordinate in the view
   * @return the coordinates of the tile under this pixel, null if outside of grid
   */
  Location viewToModel(int x,int y) {
    if(x<0)
      x-=(tileWidth-1);
    if(y<0)
      y-=(tileHeight-1);
    int cellX = x/tileWidth;
    int cellY = y/tileHeight;
    return new Location(cellX,cellY);
  }
  
  /** Display a message and wait until the user validate the message box.
   * @param message the message to display
   */
  public void displayMessage(final String message) {
    if (EventQueue.isDispatchThread())
      JOptionPane.showMessageDialog(control, message);
    else {
      try {
        EventQueue.invokeAndWait(new Runnable() {
          public void run() {
            JOptionPane.showMessageDialog(control, message);
          }   
        });
      } catch (InterruptedException e) {
        Thread.currentThread().interrupt();
      } catch (InvocationTargetException e) {
        throw new AssertionError(e);
      }
    }
  }
  
  public Rectangle getFrameBounds() {
    Window window = SwingUtilities.getWindowAncestor(control);
    if (window==null)
      throw new IllegalStateException("GridPane not displayed");
    return window.getBounds();
  }
}

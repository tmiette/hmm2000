/*
 * Created on 20 sept. 2005
 */
package fr.umlv.lawrence;

import java.awt.Image;
import java.io.IOException;
import java.net.URL;
import java.util.HashMap;


/**
 * Abstract Image provider, which does image scaling
 * @author Julien Cervelle
 * 
 * @param <E> type of the elements
 * @param <S> type of the sprites
 */
public abstract class AbstractImageProvider<E,S> extends ImageProvider<E> {
  private final HashMap<E,ImagePair> imagePairMap=new HashMap<E,ImagePair>();
  private boolean sealed;
  
  private class ImagePair {
    private final S sprite;
    private Image scaled;
    
    public ImagePair(S sprite) {
      this.sprite = sprite;
    }
    public Image getScaled() {
      return scaled;
    }
    public void setScaled(Image scaled) {
      this.scaled = scaled;
    }
    public Image rescale(int tileWidth,int tileHeight) {
      return render(sprite,tileWidth, tileHeight);
    }
  }

  protected abstract Image render(S original, int tileWidth,int tileHeight);
  protected abstract S parse(URL source) throws IOException;

  @Override
  Image getImage(E t) {
    return imagePairMap.get(t).getScaled();
  }
  
  @Override
  Image[] processScaleImages(int tileWidth,int tileHeight) {
    Image[] images=new Image[imagePairMap.size()];
    int i=0;
    for(ImagePair val:imagePairMap.values()) {
      images[i++]=val.rescale(tileWidth, tileHeight);
    }
    return images;
  }
  
  @Override
  void applyScaleImages(Image[] images) {
    int i=0;
    for(ImagePair val:imagePairMap.values()) {
      val.setScaled(images[i++]);
    }
  }

  @Override
  public void registerImage(E element,URL spriteSource) {
    try {
      if(spriteSource==null)
        throw new IllegalArgumentException("null source");
      registerImage(element,parse(spriteSource));
    }
    catch(IOException e) {
      throw new IllegalArgumentException("I/O error while loading "+spriteSource,e);
    }
  }

  @Override
  void seal(int tileWidth,int tileHeight) {
    sealed=true;
    applyScaleImages(
      processScaleImages(tileWidth, tileHeight));
  }
  
  /**
   * Registers a sprite for an element.
   * It is not possible to register different sprites for the same element.
   * 
   * @param element the object corresponding to the sprite
   * @param sprite the sprite
   * 
   * @throws IllegalArgumentException if a sprite is already registered for the element
   *         or if the image provider is in use.  
   */
  public void registerImage(E element,S sprite) {
    ImagePair pair = imagePairMap.get(element);
    if (sealed||pair!=null)
      throw new IllegalArgumentException("Object already registered or class sealed");
    pair = new ImagePair(sprite);
    imagePairMap.put(element, pair);
  }
}

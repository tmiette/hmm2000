/*
 * Created on 23 sept. 2005
 */
package fr.umlv.lawrence;

import java.awt.EventQueue;
import java.awt.GridBagLayout;
import java.awt.Rectangle;
import java.awt.event.MouseWheelEvent;
import java.awt.event.MouseWheelListener;
import java.lang.reflect.InvocationTargetException;
import java.util.concurrent.Executors;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;

import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JScrollPane;


public class Application {
  static final LinkedBlockingQueue<Runnable> taskQueue = new LinkedBlockingQueue<Runnable>(4000);
  static final LinkedBlockingQueue<Runnable> priorityTaskQueue = new LinkedBlockingQueue<Runnable>();
  
  private static final Thread applicationThread = new Thread(new Runnable() {
    public void run() {
      try {
        for(;;) {
          while(!priorityTaskQueue.isEmpty())
            priorityTaskQueue.take().run();
          taskQueue.take().run();
        }
      } catch (InterruptedException e) {
        new IllegalStateException("Application thread must not be interrupted",e).printStackTrace();
      } catch(Throwable t) {
        t.printStackTrace();
      }
    }
  },"Lawrence-Event-Queue");
  static {
    applicationThread.setDaemon(true);
    applicationThread.start();
  }

  private static final Runnable EMPTY_RUNNABLE = new Runnable() {
    public void run() { // empty task to awake taskQueue
    }
  };

  /** Post a runnable to be executed by the application thread.
   * @param runnable the runnable to execute.
   */
  public static void postInApplicationThread(Runnable runnable) {
    try {
      if (Thread.currentThread()==applicationThread)
        runnable.run();
      else if (EventQueue.isDispatchThread()) {
        priorityTaskQueue.add(runnable);
        taskQueue.offer(EMPTY_RUNNABLE);
      }
      else
        taskQueue.put(runnable);
    } catch (InterruptedException e) {
      Thread.currentThread().interrupt();
    }
  }

  /** Creates and executes a one-shot action that becomes enabled after the given delay
   *  in the application thread.
   *  
   * @param command the command to execute
   * @param delay the time from now to delay execution
   * @param unit the time unit of the delay parameter
   * @return a ScheduledFuture representing pending completion of the task and
   *         whose get() method will return null upon completion.
   */
  public static ScheduledFuture<?> schedule(Runnable command, long delay, TimeUnit unit) {
    Runnable runnable=postInApplicationThreeadRunnable(command);
    return SchedulerCache.executors.schedule(runnable, delay, unit);
  }
  
  /** Creates and executes a periodic action that becomes enabled first after the given
   * initial delay, and subsequently with the given period; that is executions will
   * commence after initialDelay then initialDelay+period, then initialDelay + 2 * period,
   * and so on.
   * If any execution of the task encounters an exception, subsequent executions are
   * suppressed.
   * Otherwise, the task will only terminate via cancellation or termination of the executor.
   * If any execution of this task takes longer than its period, then subsequent executions
   * may start late, but will not concurrently execute.
   * 
   * @param command the command to execute
   * @param initialDelay  the time to delay first execution
   * @param period the period between successive executions
   * @param unit the time unit of the initialDelay and period parameters
   * @return a ScheduledFuture representing pending completion of the task, and whose get()
   *         method will throw an exception upon cancellation
   */
  public static ScheduledFuture<?> scheduleAtFixedRate(Runnable command, long initialDelay, long period, TimeUnit unit) {
    Runnable runnable=postInApplicationThreeadRunnable(command);
    return SchedulerCache.executors.scheduleAtFixedRate(runnable,initialDelay,period,unit);
  }
  
  /** Creates and executes a periodic action that becomes enabled first after
   *  the given initial delay, and subsequently with the given delay between
   *  the termination of one execution and the commencement of the next.
   *  If any execution of the task encounters an exception, subsequent executions
   *  are suppressed.
   *  Otherwise, the task will only terminate via cancellation or termination of the executor.
   * 
   * @param command the command to execute
   * @param initialDelay the time to delay first execution
   * @param delay the time from now to delay execution
   * @param unit the time unit of the initialDelay and period parameters
   * @return a ScheduledFuture representing pending completion of the task,
   *         and whose get() method will throw an exception upon cancellation
   */
  public static ScheduledFuture<?> scheduleWithFixedDelay(Runnable command, long initialDelay, long delay, TimeUnit unit) {
    Runnable runnable=postInApplicationThreeadRunnable(command);
    return SchedulerCache.executors.scheduleWithFixedDelay(runnable,initialDelay,delay,unit);
  }
  
  private static Runnable postInApplicationThreeadRunnable(final Runnable command) {
    return new Runnable() {
      public void run() {
        postInApplicationThread(command);
      }
    };
  }
  
  static class SchedulerCache {
    static final ScheduledExecutorService executors=
      Executors.newSingleThreadScheduledExecutor();
  }
  
  /**
   * Opens a window containing the given view with given title, optional scroll bars
   * and optional ability to zoom using the mouse wheel.
   * @param pane the grid pane to display
   * @param title the title of the window
   * @param scrolls tells whether scroll bars are to be displayed
   * @param zoom tells whether wheel zooms
   */
  public static void display(final GridPane<?> pane,String title,boolean scrolls, boolean zoom) {
    display(pane,title,scrolls,zoom?2:0,3,256);  
  }
  
  // compute baseValue*factor^exponent
  static int computeSize(int baseValue, double factor, int exponent) {
    if (exponent==0)
      return baseValue;
    double d = baseValue*Math.exp(exponent*Math.log(factor));
    return (int)d;
  }

  /**
   * Opens a window containing the given view with given title, optional scroll bars
   * and optional ability to zoom using the mouse wheel.
   * @param pane the grid pane to display
   * @param title the title of the window
   * @param scrolls tells whether scroll bars are to be displayed
   * @param zoomFactor tells how much whether wheel zooms, 0 to disable this feature
   */
  public static void display(final GridPane<?> pane,
      String title,boolean scrolls,
      final double zoomFactor,final int minSize, final int maxSize) {
    display(pane, title, scrolls, zoomFactor, minSize, maxSize,null);
  }
  /**
   * Opens a window containing the given view with given title, optional scroll bars
   * and optional ability to zoom using the mouse wheel.
   * @param pane the grid pane to display
   * @param title the title of the window
   * @param scrolls tells whether scroll bars are to be displayed
   * @param zoomFactor tells how much whether wheel zooms, 0 to disable this feature
   * @param bounds bounds for displayed window (can be {@code null})
   */
  public static void display(final GridPane<?> pane,
      String title,boolean scrolls,
      final double zoomFactor,final int minSize, final int maxSize,
      Rectangle bounds) {
    if (zoomFactor!=0&&zoomFactor<1)
      throw new IllegalArgumentException("invalid zoom factor "+zoomFactor);
    JComponent control=pane.getControl();
    if (zoomFactor!=0) {
      control.addMouseWheelListener(new MouseWheelListener() {
        private final int baseHeight = pane.getTileHeight();
        private final int baseWidth = pane.getTileWidth();
        private int logScale;
        public void mouseWheelMoved(MouseWheelEvent e) {
          int r = e.getWheelRotation();
          
          int height;
          int width;
          if (r==0)
            return;
          else if (r>0) {
            do {
              logScale++;
              r--;
              height=computeSize(baseHeight,zoomFactor,logScale);
              width=computeSize(baseWidth,zoomFactor,logScale);
            } while(height<=maxSize && width<=maxSize && r!=0);
            if (height>maxSize || width>maxSize) {
              logScale--;
              height=computeSize(baseHeight,zoomFactor,logScale);
              width=computeSize(baseWidth,zoomFactor,logScale);
            }
          } 
          else {
            do {
              logScale--;
              r++;
              height=computeSize(baseHeight,zoomFactor,logScale);
              width=computeSize(baseWidth,zoomFactor,logScale);
            } while(height>=minSize && width>=minSize && r!=0);
            if (height<minSize && width<minSize) {
              logScale++;
              height=computeSize(baseHeight,zoomFactor,logScale);
              width=computeSize(baseWidth,zoomFactor,logScale);
            }
          }
          pane.setTileDimension(width,height);
        }

      });
    }
    openFrame(control,title,scrolls,bounds);

    // wait until frame open
    try {
      EventQueue.invokeAndWait(new Runnable() {
        public void run() {
          // do nothing, it is just synchronization.
        }
      });
    } catch (InterruptedException e) {
      throw new AssertionError(e);
    } catch (InvocationTargetException e) {
      throw new AssertionError(e);
    }
  }

  private static void openFrame(JComponent control, String title, boolean scrolls, Rectangle bounds) {
    if (scrolls)
      control = new JScrollPane(control);
    JFrame frame = new JFrame(title);
    if(!scrolls) 
      frame.setLayout(new GridBagLayout());
    frame.add(control);
    frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
    if (bounds!=null)
      frame.setBounds(bounds);
    else
      frame.pack();
    frame.setVisible(true);
  }
}

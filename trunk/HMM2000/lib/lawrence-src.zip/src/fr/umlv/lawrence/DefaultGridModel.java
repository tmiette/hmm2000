/*
 * Created on 20 sept. 2005
 */
package fr.umlv.lawrence;

import java.awt.EventQueue;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.LinkedBlockingQueue;


/**
 * Default implementation of a GridModel whose back end are two ArrayList (for
 * double buffering), where update can either be direct, or using back buffer
 * 
 * @param <E> type of cell elements.
 * 
 * @author Julien Cervelle
 */
public class DefaultGridModel<E> extends GridModel<E> {
  final int height,width;
  ArrayList<E>[] data,newData;
  int minx,maxx,miny,maxy;
  final HashMap<Location,E> highligthMap;
  
  private final CopyOnWriteArrayList<GridListener> listeners=
    new CopyOnWriteArrayList<GridListener>();

  private DefaultGridModel(int width,int height,@SuppressWarnings("unused") boolean dummy) {
    this.width=width;
    this.height=height;

    highligthMap=new HashMap<Location,E>();
    
    maxx=maxy=-1;
    minx=width;
    miny=height;
  }

  /**
   * Construct of GridModel, given its dimension and the initial content of
   * each cells
   * @param height height of the grid
   * @param width width of the grid
   * @param defaultValue elements of all cells
   */
  public DefaultGridModel(int width,int height, Collection<? extends E> defaultValue) {
    this(width,height,false);
    if (width==0)
      throw new IllegalArgumentException("null width");
    if (height==0)
      throw new IllegalArgumentException("null height");

    int size=width*height;
    @SuppressWarnings("unchecked") ArrayList<E>[] data = (ArrayList<E>[]) new ArrayList<?>[size];
    this.data = data;
    @SuppressWarnings("unchecked")  ArrayList<E>[] newData = (ArrayList<E>[]) new ArrayList<?>[size];
    this.newData = newData;
    for(int i=0;i<size;i++) {
      ArrayList<E> list = new ArrayList<E>();
      data[i]=list;
      ArrayList<E> list2 = new ArrayList<E>();
      newData[i]=list2;
      set(data,i,defaultValue);
      set(newData,i,defaultValue);
    }
  }
  
  public DefaultGridModel(int width,int height) {
    this(width,height,Collections.<E>emptyList());
  }

  /**
   * Construct of GridModel, given its dimension and the initial content of
   * each cells
   * @param init initial values of the model, first coordinate is abscisse and second is ordinate
   */
  public DefaultGridModel(Collection<? extends E>[][] init) {
    this(init.length,init[0].length,false);
    if (width==0)
      throw new IllegalArgumentException("null array width");
    if (height==0)
      throw new IllegalArgumentException("null array height");
    for(int x=1;x<width;x++)
      if (init[x].length!=height)
        throw new IllegalArgumentException("subarrays of various length");
    int size=width*height;

    @SuppressWarnings("unchecked") ArrayList<E>[] data = (ArrayList<E>[]) new ArrayList<?>[size];
    this.data = data;
    @SuppressWarnings("unchecked")  ArrayList<E>[] newData = (ArrayList<E>[]) new ArrayList<?>[size];
    this.newData = newData;

    for(int x=0;x<width;x++)
      for(int y=0;y<height;y++) {
        ArrayList<E> list = new ArrayList<E>();
        int index=computeIndex(x, y);
        data[index]=list;
        ArrayList<E> list2 = new ArrayList<E>();
        newData[index]=list2;
        set(data,index,init[x][y]);
        set(newData,index,init[x][y]);
      }
  }

  static <T> void set(ArrayList<T>[] bank,int index,Collection<? extends T> values) {
    ArrayList<T> target = bank[index];
    target.clear();
    target.addAll(values);
  }

  @Override
  public int getHeight() {
    return height;
  }

  @Override
  public int getWidth() {
    return width;
  }

  @Override
  Collection<? extends E> getElements(int x, int y) {
    return data[computeIndex(x,y)];
  }

  @Override
  Map<Location, ? extends E> getHighlightedElements() {
    return highligthMap;
  }

  /** Set or remove the highlight element at a location.
   *  If the element is null, the current highlight element
   *  at the location is removed.
   * 
   * @param x the abscissa of the highlight element.
   * @param y the ordinate of the highlight element.
   * @param element the highlight element or null to remove it.
   */
  public void setHighligthElement(int x,int y,E element) {
    setHighligthElement(new Location(x,y),element);
  }

  /** Set or remove the highlight element at a location.
   *  If the element is null, the current highlight element
   *  at the location is removed.
   * 
   * @param location the location of the highlight element.
   * @param element the  highlight element or null.
   */
  public void setHighligthElement(final Location location,final E element) {
    Application.postInApplicationThread(new Runnable() {
      public void run() {
        post(new Runnable() {
          public void run() {
            if (element==null)
              highligthMap.remove(location);
            else
              highligthMap.put(location,element);

            fireAreaChanged(location.getX(),location.getY(),1,1);
          }
        });
      }
    });
  }

  /* returns the index in data of cell (x,y) */
  int computeIndex(int x,int y) {
    return y*width+x;
  }

  /**
   * Add an element to cell (x,y), asking the change to be
   * done in the back buffer, and only displayed by a call to {@link #swap()}.
   * 
   * @param x x coordinate of the cell
   * @param y y coordinate of the cell
   * @param element new cell content
   * 
   * @see #swap()
   */
  public void addDeffered(final int x,final int y,final E element) {
    defer(new Runnable() {
      public void run() {
        int index = computeIndex(x,y);
        newData[index].add(element);
        updateMinMax(x,y);
      }
    });
  }
  
  /**
   * Insert an element in cell (x,y), asking the change to be
   * done in the back buffer, and only displayed by a call to {@link #swap()}.
   * 
   * @param x x coordinate of the cell
   * @param y y coordinate of the cell
   * @param element new cell content
   * @param position position to insert the element
   * 
   * @see #swap()
   */
  public void insertDeffered(final int x,final int y,final E element,final int position) {
    defer(new Runnable() {
      public void run() {
        int index = computeIndex(x,y);
        newData[index].add(position,element);
        updateMinMax(x,y);
      }
    });
  }

  /**
   * set element to cell (x,y), asking the change to be
   * done in the back buffer, and only displayed by a call to {@link #swap()}.
   * 
   * @param x x coordinate of the cell
   * @param y y coordinate of the cell
   * @param element new cell content
   * @param position position to insert the element
   * 
   * @see #swap()
   */
  public void setAtDeffered(final int x,final int y,final E element,final int position) {
    defer(new Runnable() {
      public void run() {
        int index = computeIndex(x,y);
        newData[index].set(position,element);
        updateMinMax(x,y);
      }
    });
  }

  /**
   * remove element to cell (x,y), asking the change to be
   * done in the back buffer, and only displayed by a call to {@link #swap()}.
   * 
   * @param x x coordinate of the cell
   * @param y y coordinate of the cell
   * @param element to remove
   * 
   * @see #swap()
   */
  public void removeDeffered(final int x,final int y,final E element) {
    defer(new Runnable() {
      public void run() {
        int index = computeIndex(x,y);
        if (newData[index].remove(element))
          updateMinMax(x,y);
      }
    });
  }

  /**
   * remove element to cell (x,y), asking the change to be
   * done in the back buffer, and only displayed by a call to {@link #swap()}.
   * 
   * @param x x coordinate of the cell
   * @param y y coordinate of the cell
   * @param position the position of the element in the cell to remove
   * 
   * @see #swap()
   */
  public void removeAtDeffered(final int x,final int y,final int position) {
    defer(new Runnable() {
      public void run() {
        int index = computeIndex(x,y);
        newData[index].remove(position);
        updateMinMax(x,y);
      }
    });
  }

  
  /**
   * Change all elements of cell (x,y), asking the change to be
   * done in the back buffer, and only displayed by a call to {@link #swap()}.
   * 
   * @param x x coordinate of the cell
   * @param y y coordinate of the cell
   * @param elements new cell content
   * 
   * @see #swap()
   */
  public void setDeffered(final int x,final int y,Collection<? extends E> elements) {
    final ArrayList<E> copy = new ArrayList<E>(elements);
    defer(new Runnable() {
      public void run() {
        int index = computeIndex(x,y);
        set(newData,index,copy);
        updateMinMax(x,y);
      }
    });
  }
  
  private void defer(final Runnable runnable) {
    Application.postInApplicationThread(new Runnable() {
      public void run() {
        post(runnable);
      }
    });
  }
  
  void updateMinMax(int x,int y) {
    if (minx>x)
      minx=x;
    if (maxx<x+1)
      maxx=x+1;
    if (miny>y)
      miny=y;
    if (maxy<y+1)
      maxy=y+1;
  }

  /**
   * Ask deferred changes to become effective. Listeners are notified of the
   * change.
   * 
   * @see #setDeffered(int, int, Collection)
   */
  public void swap() {
    Application.postInApplicationThread(new Runnable() {
      public void run() {
        post(new Runnable() {
          public void run() {
            if (maxx==-1 || maxy==-1)
              return;

            ArrayList<E>[] tmp = data;
            data = newData;
            newData = tmp;
            fireAreaChanged(minx, miny, maxx-minx, maxy-miny);

            maxx=maxy=-1;
            minx=width;
            miny=height;
          }
        });

        for(int i=0;i<data.length;i++) {
          final int index=i;
          post(new Runnable() {
            public void run() {
              set(newData,index,data[index]);
            }
          });
        }
      }
    });
  }

  void post(Runnable runnable) {
    try {
      taskQueue.put(runnable);
    } catch (InterruptedException e) {
      Thread.currentThread().interrupt();
    }
    if (!started) {
      started=true;
      currentRunnable++;
      EventQueue.invokeLater(new TaskQueueRunnable(currentRunnable));
    }
  }

  private final LinkedBlockingQueue<Runnable> taskQueue = new LinkedBlockingQueue<Runnable>(4000);;
  volatile boolean started;
  volatile int currentRunnable;

  private class TaskQueueRunnable implements Runnable {
    private final int number;
    
    public TaskQueueRunnable(int number) {
      this.number = number;
    }

    public void run() {
      started=false;
      for(int i=0;i<20;i++) {
        Runnable runnable = taskQueue.poll();
        if (runnable==null) {
          return;
        }
        runnable.run();
      }
      if (!taskQueue.isEmpty() && (number==currentRunnable)) {
        started=true;
        EventQueue.invokeLater(this);
      }
    }
  }
  

  @Override
  public void addGridListener(GridListener listener) {
    listeners.add(listener);
  }

  @Override
  public void removeGridListener(GridListener listener) {
    listeners.remove(listener);
  }

  /**
   * Notify registered GridListener that the cells within the rectangle whose
   * upper-left corner has coordinate (x,y), width dx
   * and height dy has changed
   * @param x x coordinate of the rectangle whose cells has changed
   * @param y y coordinate of the rectangle whose cells has changed
   * @param dx width of the rectangle whose cells has changed
   * @param dy height of the rectangle whose cells has changed
   */
  void fireAreaChanged(int x,int y,int dx,int dy) {
    for (GridListener listener:listeners) {
      listener.areaChanged(x, y, dx, dy);
    }
  }
  
  /**
   * Returns if a location lies within the model
   * @param location the location
   * @return if a location lies within the model
   */
  public boolean contains(Location location) {
    int cellX=location.getX();
    int cellY=location.getY();
    return (cellY<getHeight() && cellX<getWidth()&&cellX>=0&&cellY>=0);
  }
}

package fr.umlv.lawrence.svg;

import java.awt.Image;
import java.io.IOException;
import java.net.URL;

import org.apache.batik.dom.svg.SVGDOMImplementation;
import org.apache.batik.dom.svg.SVGOMDocument;
import org.apache.batik.dom.util.SAXDocumentFactory;
import org.apache.batik.transcoder.TranscoderException;
import org.apache.batik.util.SVGConstants;
import org.apache.batik.util.XMLResourceDescriptor;

import fr.umlv.lawrence.AbstractImageProvider;

public class SVGImageProvider<E> extends AbstractImageProvider<E, SVGOMDocument>{
  
  private final BufferedImageTranscoder transcoder=
    new BufferedImageTranscoder();
  private final SAXDocumentFactory factory=
    new SAXDocumentFactory(
        SVGDOMImplementation.getDOMImplementation(),
        XMLResourceDescriptor.getXMLParserClassName());
  
  @Override
  protected SVGOMDocument parse(URL source) throws IOException {
   return (SVGOMDocument) factory.createDocument(
       SVGConstants.SVG_NAMESPACE_URI,
       SVGConstants.SVG_SVG_TAG,
       source.toExternalForm());
  }

  @Override
  protected Image render(SVGOMDocument original, int tileWidth, int tileHeight) {
    transcoder.setTargetWidth(tileWidth);
    transcoder.setTargetHeight(tileHeight);
    try {
      transcoder.transcode(original);
    } catch (TranscoderException e) {
      throw new AssertionError(e);
    }
    return transcoder.getRenderedImage();
  }

  public void setDPI(double dpi) {
    transcoder.setDPI(dpi);
  }
  
  
}

package fr.umlv.lawrence;

/**
 * @author Remi
 */
public class Location {
  private final int x,y;
  
  public Location(int x,int y) {
    this.x=x;
    this.y=y;
  }
  
  @Override
  public int hashCode() {
    return x ^ Integer.rotateLeft(y,16);
  }

  @Override
  public boolean equals(Object obj) {
    if (!(obj instanceof Location))
      return false;
    Location location=(Location)obj;
    return location.x==x && location.y==y;
  }

  public int getX() {
    return x;
  }
  public int getY() {
    return y;
  }
  
  @Override
  public String toString() {
    return "("+x+","+y+")";
  }
}

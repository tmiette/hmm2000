/*
 * Created on 20 sept. 2005
 */
package fr.umlv.lawrence;

import java.awt.Image;
import java.net.URL;

/**
 * Image provider, which does image scaling
 * @author Julien Cervelle
 * 
 * @param <E> type of the elements
 */
public abstract class ImageProvider<E> {
  /** Returns an image corresponding to the element taken as argument.
   * @param element the element
   * @return an image representing the element.
   */
  abstract Image getImage(E element);
  
  abstract void seal(int tileWidth,int tileHeight);

  /** Proceed scale images.
   * @param tileWidth new tile width
   * @param tileHeight new tile height
   * @return an array of scaled image.
   */
  abstract Image[] processScaleImages(int tileWidth,int tileHeight);
  
  /** Apply scaled images.
   * @param images an array containing all rescaled images.
   */
  abstract void applyScaleImages(Image[] images);
  
  /**
   * Registers a sprite for an element has to be read from an URL. 
   * @param element the object corresponding to the sprite
   * @param spriteSource the source of the sprite
   * 
   * @throws IllegalArgumentException when an I/O exception occurs
   *  or if a sprite is already registered for the element
   *  or if the image provider is already in use.
   *  
   * @see java.lang.Class#getResource(String)
   */
  public abstract void registerImage(E element,URL spriteSource);
}

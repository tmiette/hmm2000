/*
 * Created on 22 sept. 2005
 */
package fr.umlv.lawrence;

import java.util.EventListener;

public interface InputListener extends EventListener {
  /**
   * Indicates that a cell was clicked
   * @param x the x coordinate of the cell
   * @param y the y coordinate of the cell
   * @param button the number of the pressed button
   */
  public void mouseClicked(int x,int y,int button);
  
  /**
   * Indicates that a key was pressed
   * @param x the x coordinate of the cell where the cursor was when the key was pressed
   * @param y the y coordinate of the cell where the cursor was when the key was pressed
   * @param keyCode Which key was pressed
   */
  public void keyTyped(int x,int y,Key keyCode);
}
